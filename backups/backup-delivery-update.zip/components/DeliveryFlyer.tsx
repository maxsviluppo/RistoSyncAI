import React from 'react';
import QRCode from 'react-qr-code';
import { ChefHat, Phone, Globe, Bike, MapPin } from 'lucide-react';
import { RestaurantProfile } from '../types';

interface DeliveryFlyerProps {
    restaurantProfile: RestaurantProfile;
    publicUrl: string;
    onClose: () => void;
}

export default function DeliveryFlyer({ restaurantProfile, publicUrl, onClose }: DeliveryFlyerProps) {

    const handlePrint = () => {
        window.print();
    };

    return (
        <div className="fixed inset-0 z-[100] bg-slate-900 overflow-auto flex flex-col items-center">
            {/* TOOLBAR - Non stampabile */}
            <div className="print:hidden fixed top-0 left-0 right-0 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 p-4 flex items-center justify-between z-50">
                <div className="flex items-center gap-3">
                    <Bike className="text-orange-500" size={24} />
                    <h1 className="text-white font-bold text-lg">Locandina Delivery (A5)</h1>
                </div>
                <div className="flex gap-3">
                    <button
                        onClick={handlePrint}
                        className="px-6 py-2 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold rounded-xl transition-all shadow-lg flex items-center gap-2"
                    >
                        🖨️ Stampa / PDF
                    </button>
                    <button
                        onClick={onClose}
                        className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl transition-colors"
                    >
                        ✕ Chiudi
                    </button>
                </div>
            </div>

            {/* CONTENUTO STAMPABILE - A5 FORMAT (148mm x 210mm) */}
            <div className="pt-24 pb-20 print:pt-0 print:pb-0 w-full max-w-[14.8cm] print:max-w-none mx-auto">
                <div className="bg-slate-950 text-white w-full aspect-[148/210] shadow-2xl print:shadow-none print:w-full print:h-screen flex flex-col relative overflow-hidden border-8 border-slate-900">

                    {/* Background Pattern Aggressivo */}
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-orange-900/30 via-slate-950 to-slate-950 z-0"></div>

                    {/* HEADER */}
                    <div className="relative z-10 bg-slate-900/80 p-8 text-center pb-6">
                        {/* Logo */}
                        <div className="w-32 h-32 rounded-full border-4 border-orange-600 shadow-[0_0_30px_rgba(234,88,12,0.4)] mx-auto mb-4 bg-slate-800 flex items-center justify-center overflow-hidden relative group">
                            {restaurantProfile.logo ? (
                                <img src={restaurantProfile.logo} alt="Logo" className="w-full h-full object-cover" />
                            ) : (
                                <ChefHat size={48} className="text-orange-500" />
                            )}
                        </div>
                        <h1 className="text-3xl font-black uppercase tracking-tighter text-white mb-1 leading-none drop-shadow-lg">
                            {restaurantProfile.name || 'Ristorante Demo'}
                        </h1>
                        <p className="text-orange-500 font-bold tracking-[0.2em] text-[10px] uppercase">
                            Official Delivery
                        </p>
                    </div>

                    {/* DIVIDER ARANCIO */}
                    <div className="relative z-10 w-full h-3 bg-gradient-to-r from-orange-600 via-yellow-500 to-orange-600 shadow-[0_0_20px_rgba(234,88,12,0.6)]">
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-slate-950 px-4 text-orange-500">
                            <Bike size={24} fill="currentColor" />
                        </div>
                    </div>

                    {/* BODY - QR CODE & CTA */}
                    <div className="relative z-10 flex-1 flex flex-col items-center justify-center p-8 space-y-8 bg-gradient-to-b from-slate-900 to-black">

                        <div className="text-center space-y-1">
                            <h2 className="text-3xl font-black italic text-white tracking-tight">ORDINA ORA!</h2>
                            <p className="text-slate-400 text-xs font-medium uppercase tracking-wide">Scansiona per il menu completo</p>
                        </div>

                        {/* Box QR Code */}
                        <div className="p-4 bg-white rounded-2xl shadow-[0_0_40px_rgba(255,255,255,0.1)] rotate-2 hover:rotate-0 transition-transform duration-500 border-4 border-orange-500 relative group">
                            <div className="absolute -top-3 -right-3 bg-red-600 text-white text-[10px] font-black px-2 py-1 rounded shadow-lg animate-pulse uppercase">
                                Scan Me
                            </div>
                            <QRCode value={publicUrl} size={180} />
                        </div>

                        {/* Info Contatti */}
                        <div className="w-full bg-white/5 rounded-2xl p-6 border border-white/10 backdrop-blur-sm text-center">
                            {restaurantProfile.phoneNumber && (
                                <div className="flex items-center justify-center gap-2 text-2xl font-black text-white mb-2 tracking-tight">
                                    <Phone className="text-orange-500 fill-orange-500" size={20} />
                                    {restaurantProfile.phoneNumber}
                                </div>
                            )}
                            <div className="flex items-center justify-center gap-2 text-xs text-slate-500 font-mono overflow-hidden text-ellipsis whitespace-nowrap px-4 bg-black/30 py-1 rounded-full mx-auto w-max max-w-full">
                                <Globe size={10} /> {publicUrl.replace(/^https?:\/\//, '')}
                            </div>
                        </div>

                        {/* Footer Strip */}
                        <div className="absolute bottom-0 left-0 right-0 h-2 bg-orange-600/20"></div>
                    </div>
                </div>
            </div>

            {/* CSS STAMPA */}
            <style>{`
                @media print {
                    @page {
                        size: A5;
                        margin: 0;
                    }
                    body {
                        -webkit-print-color-adjust: exact !important;
                        print-color-adjust: exact !important;
                        background: white;
                    }
                    /* Nascondi scrollbar e UI browser */
                    ::-webkit-scrollbar { display: none; }
                    
                    /* Resetta padding/margini */
                    .print\\:pt-0 { padding-top: 0 !important; }
                    .print\\:pb-0 { padding-bottom: 0 !important; }
                    .print\\:shadow-none { box-shadow: none !important; }
                    .print\\:w-full { width: 100% !important; max-width: none !important; }
                    .print\\:h-screen { height: 100vh !important; }
                    
                    /* Nascondi app */
                    #root > *:not([class*="fixed"]) {
                        display: none;
                    }
                }
            `}</style>
        </div>
    );
}
