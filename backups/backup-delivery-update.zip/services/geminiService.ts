
import { GoogleGenAI } from "@google/genai";
import { MenuItem } from "../types";
import { getGoogleApiKey } from "./storageService";

export const askChefAI = async (query: string, currentItem: MenuItem | null): Promise<string> => {
    try {
        const apiKey = getGoogleApiKey() || process.env.API_KEY;
        if (!apiKey) {
            return "⚠️ Configurazione AI mancante. Vai nelle Impostazioni > AI Intelligence e inserisci la tua Google API Key.";
        }

        const ai = new GoogleGenAI({ apiKey });

        const context = currentItem
            ? `Il cliente sta chiedendo informazioni sul piatto: "${currentItem.name}". Ingredienti: ${currentItem.ingredients || 'Non specificati'}. Descrizione: ${currentItem.description || 'Nessuna'}. Allergeni: ${currentItem.allergens?.join(', ') || 'Nessuno'}.`
            : 'Il cliente sta facendo una domanda generale sul menu.';

        const prompt = `
      Sei un assistente chef esperto e cortese in un ristorante italiano.
      Contesto: ${context}
      Domanda del cliente: "${query}"
      
      Rispondi in modo conciso (max 2 frasi), professionale e invitante. 
      Se chiedono allergeni e non sei sicuro, consiglia di chiedere allo chef.
    `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text || "Non riesco a rispondere al momento.";
    } catch (error) {
        console.error("Gemini Error:", error);
        return "Errore AI. Verifica la chiave API.";
    }
};

export const generateRestaurantAnalysis = async (stats: any, date: string): Promise<string> => {
    try {
        const apiKey = getGoogleApiKey() || process.env.API_KEY;
        if (!apiKey) return "⚠️ Chiave API mancante.";

        const ai = new GoogleGenAI({ apiKey });

        const prompt = `
            Sei un Consulente Ristorazione. Analizza i dati del ${date}:
            - Incasso: € ${stats.totalRevenue.toFixed(2)}
            - Piatti: ${stats.totalItems}
            - Attesa Media: ${stats.avgWait} min
            - Top Piatti: ${JSON.stringify(stats.topDishes)}

            Fornisci un report breve (max 100 parole) con:
            1. Valutazione performance.
            2. Consiglio per migliorare incasso o efficienza domani.
            Usa emoji.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text || "Analisi non disponibile.";

    } catch (error) {
        console.error("Gemini Analysis Error:", error);
        return "Errore analisi AI.";
    }
};

export const generateDishIngredients = async (dishName: string): Promise<string> => {
    try {
        const apiKey = getGoogleApiKey() || process.env.API_KEY;
        if (!apiKey) return "";

        const ai = new GoogleGenAI({ apiKey });

        const prompt = `
            Sei uno Chef. 
            Elenca SOLO gli ingredienti principali per il piatto "${dishName}", separati da virgola.
            Non scrivere nient'altro. Solo elenco ingredienti.
            Esempio: Pasta, Uova, Guanciale, Pecorino, Pepe.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text ? response.text.replace(/\n/g, " ").trim() : "";
    } catch (error) {
        console.error("Ingredients Gen Error:", error);
        return "";
    }
};

export const generateDishDescription = async (dishName: string, ingredients: string): Promise<string> => {
    try {
        const apiKey = getGoogleApiKey() || process.env.API_KEY;
        if (!apiKey) return "";

        const ai = new GoogleGenAI({ apiKey });

        const prompt = `
            Sei uno Chef stellato che scrive il menu.
            Scrivi una descrizione breve (max 20 parole), invitante e poetica per il piatto: "${dishName}".
            Considera questi ingredienti: ${ingredients}.
            Non elencare di nuovo gli ingredienti, descrivi l'esperienza di gusto.
            Tono elegante. Niente virgolette.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text || "";
    } catch (error) {
        console.error("Description Gen Error:", error);
        return "";
    }
};

export const generateRestaurantDescription = async (restaurantName: string): Promise<string> => {
    try {
        const apiKey = getGoogleApiKey() || process.env.API_KEY;
        if (!apiKey) return "";

        const ai = new GoogleGenAI({ apiKey });

        const prompt = `
            Sei un esperto copywriter per la ristorazione.
            Scrivi una "Bio" (descrizione breve) accattivante ed elegante per il ristorante chiamato "${restaurantName}".
            Massimo 30 parole.
            Usa un tono invitante che faccia venire fame.
            Usa 1 o 2 emoji appropriate.
            Non usare virgolette.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text || "";
    } catch (error) {
        console.error("Restaurant Bio Gen Error:", error);
        return "";
    }
};

export interface ExtractedMenuItem {
    name: string;
    price: number;
    description?: string;
    category: string;
    ingredients?: string;
}

export const extractMenuFromImage = async (imageBase64: string): Promise<ExtractedMenuItem[]> => {
    try {
        const apiKey = getGoogleApiKey() || process.env.API_KEY;
        if (!apiKey) {
            console.error("API Key mancante");
            return [];
        }

        const ai = new GoogleGenAI({ apiKey });

        const prompt = `
            Sei un esperto di OCR e menu di ristoranti.
            Analizza questa foto di un menu e estrai TUTTI i piatti che riesci a leggere.
            
            Per ogni piatto estrai:
            - name: nome del piatto
            - price: prezzo in numero (solo il numero, senza simbolo €)
            - description: descrizione se presente (altrimenti stringa vuota)
            - category: categoria tra queste ESATTE: "Antipasti", "Panini", "Pizze", "Primi", "Secondi", "Dolci", "Bevande", "Menu Completo"
            - ingredients: ingredienti se elencati (altrimenti stringa vuota)
            
            IMPORTANTE: Rispondi SOLO con un array JSON valido, senza markdown, senza backtick, senza spiegazioni.
            Esempio formato risposta:
            [{"name":"Spaghetti Carbonara","price":12,"description":"","category":"Primi","ingredients":"Pasta, Uova, Guanciale"},{"name":"Tiramisu","price":6,"description":"Classico dolce italiano","category":"Dolci","ingredients":""}]
            
            Se non riesci a leggere nulla o l'immagine non è un menu, rispondi con: []
        `;

        // Rimuovi il prefisso data:image se presente
        const base64Data = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;

        const response = await ai.models.generateContent({
            model: 'gemini-2.0-flash',
            contents: [
                {
                    role: 'user',
                    parts: [
                        { text: prompt },
                        {
                            inlineData: {
                                mimeType: 'image/jpeg',
                                data: base64Data
                            }
                        }
                    ]
                }
            ]
        });

        const responseText = response.text || "[]";
        console.log("Gemini Vision Response:", responseText);

        // Pulisci la risposta da eventuali markdown
        let cleanJson = responseText.trim();
        if (cleanJson.startsWith('```json')) {
            cleanJson = cleanJson.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        } else if (cleanJson.startsWith('```')) {
            cleanJson = cleanJson.replace(/^```\s*/, '').replace(/\s*```$/, '');
        }

        const parsed = JSON.parse(cleanJson);

        // Valida la struttura
        if (!Array.isArray(parsed)) {
            console.error("Risposta non è un array");
            return [];
        }

        return parsed.map((item: any) => ({
            name: item.name || "Piatto senza nome",
            price: parseFloat(item.price) || 0,
            description: item.description || "",
            category: item.category || "Primi",
            ingredients: item.ingredients || ""
        }));

    } catch (error) {
        console.error("Menu Extraction Error:", error);
        return [];
    }
};

export const generateSocialPost = async (topic: string, imageContext?: string): Promise<string> => {
    try {
        const apiKey = getGoogleApiKey() || process.env.API_KEY;
        if (!apiKey) return "";

        const ai = new GoogleGenAI({ apiKey });

        const prompt = `
            Sei un Social Media Manager esperto per ristoranti.
            Scrivi un post per Facebook/Instagram basato su questo argomento: "${topic}".
            ${imageContext ? `Considera che il post avrà un'immagine che mostra: ${imageContext}` : ''}

            Il post DEVE avere questa struttura esatta:
            1. Un TITOLO ACCATTIVANTE (in maiuscolo, max 5 parole, con emoji)
            2. Un corpo del testo di ALMENO 5 righe, usando un linguaggio persuasivo, emozionale e che faccia venire fame.
            3. Una CALL TO ACTION finale chiara (es. "Prenota ora", "Vieni a trovarci").
            4. Esattamente 10 HASHTAG pertinenti alla fine.

            Usa molte emoji nel testo.
            Tono: Entusiasta, Caldo, Invitante.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text || "";
    } catch (error) {
        console.error("Social Post Gen Error:", error);
        return "Errore nella generazione del post.";
    }
};